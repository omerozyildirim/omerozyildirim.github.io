var x_coord;
var y_coord;
var width;
var height;
var steps = 20;
var t;

function reset(){
	x_coord = 0;
	y_coord = 0;
	width = 9920;
	height = 15035;
	slide_to(x_coord, y_coord, width, height);
}

function select_district(dummy){
	//document.getElementById("out_dist_name").value = dummy;
	var dist_path = document.getElementById("svg_map").getElementById(dummy);
	var bbox = dist_path.getBBox();
	var x = bbox.x;
	var y = bbox.y;
	var w = bbox.width;
	var h = bbox.height;
	//console.log(x, y, w, h)
	slide_to(x, y, w, h);
}

function slide_to(dummy1, dummy2, dummy3, dummy4){
	var dx = (dummy1 - x_coord) / steps;
	var dy = (dummy2 - y_coord) / steps;
	var dw = (dummy3 - width) / steps;
	var dh = (dummy4 - height) / steps;
	var i;
	for(i = 0; i <= steps; i++){
		x_coord += dx;
		y_coord += dy;
		width += dw;
		height += dh;
		t = setTimeout(dummyfn, 500);
		//set_pos(x_coord, y_coord, width, height);
	}
	x_coord = dummy1;
	y_coord = dummy2;
	width = dummy3;
	height = dummy4;
	//set_pos(x_coord, y_coord, width, height);
}

function set_pos(dummy1, dummy2, dummy3, dummy4){
	var vbparams = dummy1.toString() + " " + dummy2.toString() + " " + dummy3.toString() + " " + dummy4.toString();
	document.getElementById("svg_map").setAttribute("viewBox", vbparams);
}

function dummyfn(){
	set_pos(x_coord, y_coord, width, height);
	clearInterval(t);
}
