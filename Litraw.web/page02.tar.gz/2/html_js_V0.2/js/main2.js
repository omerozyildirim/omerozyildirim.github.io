var x_coord = 0;
var y_coord = 0;
var width = 9920;
var height = 15035;
var steps = 10;
var duration = 400; // milliseconds
var i;
var x;
var y;
var w;
var h;
var dx;
var dy;
var dw;
var dh;
var timerFunction = null;

function startAnimation() {
	i = 0;
	if(timerFunction == null) timerFunction = setInterval(animate, duration / steps);
}

function stopAnimation() {
	if(timerFunction != null){
		clearInterval(timerFunction);
		timerFunction = null;
	}
}

function reset(){
	x = 0;
	y = 0;
	w = 9920;
	h = 15035;
	dx = (x - x_coord) / steps;
	dy = (y - y_coord) / steps;
	dw = (w - width) / steps;
	dh = (h - height) / steps;
	startAnimation();
}

function select_district(dummy){
	var dist_path = document.getElementById("svg_map").getElementById(dummy);
	var bbox = dist_path.getBBox();
	x = bbox.x;
	y = bbox.y;
	w = bbox.width;
	h = bbox.height;
	dx = (x - x_coord) / steps;
	dy = (y - y_coord) / steps;
	dw = (w - width) / steps;
	dh = (h - height) / steps;
	startAnimation();
}

function animate(){
	x_coord += dx;
	y_coord += dy;
	width += dw;
	height += dh;
	i++;
	document.getElementById("svg_map").setAttribute("viewBox", x_coord.toString() + " " + y_coord.toString() + " " + width.toString() + " " + height.toString());
	if (i == steps){
		stopAnimation();
	}
}

function colorize(){
	var j;
	var red;
	var green;
	var blue;
	var colorstr;
	pathlist = document.getElementById("svg_map").getElementsByTagName("path");
	//console.log(list);
	for(j = 0; j < pathlist.length; j++){
		red   = parseInt(Math.random() * 255);
		green = parseInt(Math.random() * 255);
		blue  = parseInt(Math.random() * 255);
		colorstr = "rgb(" + red.toString() + ", " + green.toString() + ", " + blue.toString() + ")"
		console.log(red, green, blue, colorstr);
		pathlist[j].setAttribute("fill", colorstr);
	}
}

function clear_colors(){
	document.getElementById("svg_map").getElementById("svg_atakent"       ).setAttribute("fill", "rgb(128,255,255)");
	document.getElementById("svg_map").getElementById("svg_ataturk"       ).setAttribute("fill", "rgb(128,000,128)");
	document.getElementById("svg_map").getElementById("svg_besyol"        ).setAttribute("fill", "rgb(000,255,255)");
	document.getElementById("svg_map").getElementById("svg_cennet"        ).setAttribute("fill", "rgb(128,255,128)");
	document.getElementById("svg_map").getElementById("svg_cumhuriyet"    ).setAttribute("fill", "rgb(128,128,255)");
	document.getElementById("svg_map").getElementById("svg_fatih"         ).setAttribute("fill", "rgb(000,255,000)");
	document.getElementById("svg_map").getElementById("svg_fevzi_cakmak"  ).setAttribute("fill", "rgb(255,255,000)");
	document.getElementById("svg_map").getElementById("svg_gultepe"       ).setAttribute("fill", "rgb(000,128,128)");
	document.getElementById("svg_map").getElementById("svg_halkali_merkez").setAttribute("fill", "rgb(255,128,255)");
	document.getElementById("svg_map").getElementById("svg_inonu"         ).setAttribute("fill", "rgb(255,255,128)");
	document.getElementById("svg_map").getElementById("svg_istasyon"      ).setAttribute("fill", "rgb(000,000,255)");
	document.getElementById("svg_map").getElementById("svg_kanarya"       ).setAttribute("fill", "rgb(192,192,192)");
	document.getElementById("svg_map").getElementById("svg_kartaltepe"    ).setAttribute("fill", "rgb(255,000,255)");
	document.getElementById("svg_map").getElementById("svg_kemalpasa"     ).setAttribute("fill", "rgb(128,000,000)");
	document.getElementById("svg_map").getElementById("svg_mehmet_akif"   ).setAttribute("fill", "rgb(255,128,128)");
	document.getElementById("svg_map").getElementById("svg_sogutlucesme"  ).setAttribute("fill", "rgb(000,128,000)");
	document.getElementById("svg_map").getElementById("svg_sultanmurat"   ).setAttribute("fill", "rgb(255,000,000)");
	document.getElementById("svg_map").getElementById("svg_tevfikbey"     ).setAttribute("fill", "rgb(000,000,128)");
	document.getElementById("svg_map").getElementById("svg_yarimburgaz"   ).setAttribute("fill", "rgb(128,128,000)");
	document.getElementById("svg_map").getElementById("svg_yenimahalle"   ).setAttribute("fill", "rgb(064,064,064)");
	document.getElementById("svg_map").getElementById("svg_yesilova"      ).setAttribute("fill", "rgb(128,128,128)");
}
